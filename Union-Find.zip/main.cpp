#include <iostream>
using namespace std;

int n;
int parent[100];
int dist[100];

int find(int v){
  if(parent[v]==v){
    return v;
  }
  return find(parent[v]);
}

void combine(int v,int w){
  int v1 = find(v);
  int w1 = find(w);
  if(dist[v1]>dist[w1]){
    parent[w1] = v1;
  }else{
    parent[v1] = w1;
    dist[w1] = max(dist[w1],dist[v1]+1);
  }
}

int main() {
  std::cout << "Hello World!\n";
} 