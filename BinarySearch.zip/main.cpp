#include <iostream>

using namespace std;

//CHANGES A LOT DEPENDING ON WHAT YOU ARE DOING

bool works(int spot){
  //CAN CHANGE CONDITION
  return spot>=69;
}


int main() {
  
  int left,right;
  left = 0;
  right = 1000000;
  int ans = -69;
  while(left<=right){
    //KEEP CONSISTENT
    int mid = left+(right-left)/2;

    if(works(mid)){
      right = mid-1;
      ans = mid;
    }else{
      left = mid+1;
    }
  }
  cout<<ans;

} 