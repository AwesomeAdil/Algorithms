#include <iostream>
#include <queue>
#include <utility>
using namespace std;


//SET UP IS LIKE DIJKSTRAS
vector<pair<int,int>> adj[1005];
vector<pair<int,int>> mst[1005];
priority_queue<pair<int,pair<int,int>>, vector<pair<int,pair<int,int>>>, greater<pair<int,pair<int,int>>>> pq;
int n,m;
int dist[1005];

int main() {
  cin>>n>>m;
  for(int i=0;i<m;i++){
    int x,y,w;
    cin>>x>>y>>w;
    adj[x].push_back({w,y});
    adj[y].push_back({w,x});
  }
  for(int i=0;i<n;i++){
    dist[i]=-1;
  }
  
  int mstlength=0;
  pq.push({0,{0,0}});

  while(!pq.empty()){
    pair<int,pair<int,int>>dv;
    dv = pq.top();

    pq.pop();
    if(dist[dv.second.first]!=-1){
      continue;
    }
    mst[dv.second.second].push_back({dv.first,dv.second.first});
    mst[dv.second.first].push_back({dv.first,dv.second.second});
  

    dist[dv.second.first] = dv.first;
    mstlength += dv.first;
    for(auto j:adj[dv.second.first]){
      if(dist[j.second]==-1){
        pq.push({j.first,{j.second,dv.second.first}});
      }
    }
    
    }

    cout<<mstlength<<endl;

    for(int i=0;i<n;i++){
      cout<<i<<": ";
      for(int j=mst[i].size()-1;j>=0;j--){
        if(mst[i][j].second==i){
          mst[i].erase(mst[i].begin()+j,mst[i].begin()+j+1);
          continue;
        }
        cout<<"("<<mst[i][j].second<<","<<mst[i][j].first<<") ";
      }
      cout<<endl;
    }


    for(int i=0;i<n;i++){
      cout<<i<<": ";
      for(int j=mst[i].size()-1;j>=0;j--){
        
        cout<<"("<<mst[i][j].second<<","<<mst[i][j].first<<") ";
      }
      cout<<endl;
    }


} 