#include <iostream>
#include <queue>
#include <vector>
#include <utility>
//Shortest path
using namespace std;

vector<int> adjlist[1005];
bool visited[1005];
queue< pair< int,int > > q;
int main() {
  int n,m;
  int start, end;
  cin>>n>>m>>start>>end;
  for(int i=0;i<m;i++){
    int a,b;
    cin>>a>>b;
    adjlist[a].push_back(b);
    adjlist[b].push_back(a);
  }
  q.push({start,0});
  while(!q.empty()){
    
    pair<int,int> spot = q.front();
    if(visited[spot.first]) {continue;}
    visited[spot.first] = true;
    q.pop();
    for(int u:adjlist[spot.first]){
      if(visited[u]) {continue;}
      if(spot.first == end){
        cout<<spot.second+1;
        return 0;
      }
      q.push({u,spot.second+1});
    }
  }

} 