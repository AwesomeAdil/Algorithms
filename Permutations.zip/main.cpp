#include <iostream>
#include <algorithm>

using namespace std;

long long n = 8;
long long p[10005];
long long orig[10005];
long long counter = 0;
long long sum = 0;

void check(){
  bool add = true;
  for(long long i=0;i<n;i++){
    if(orig[i]==p[i]){
      add = false;
      break;
    }
  }
  if(add) counter++;
}

long long der(long long n, long long m){
  long long prod = 1;
  for(int i=n;i>m;i--){
    prod*=i;
  }
  return prod;
}

int main() {
  for(long long i=0;i<n;i++){
    p[i] = i;
    orig[i]=i;
  }

  do{
    check();
  }while(next_permutation(p,p+n));
  
  cout<<counter<<endl;

  for(long long i=0;i<=n;i++){
    if(i%2==0){
      sum+=der(n,i);
    }else{
      sum-=der(n,i);
    }
  }
  cout<<sum;

} 