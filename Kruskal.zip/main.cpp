#include <iostream>
#include <utility>
#include <vector>

using namespace std;

vector<pair<int,pair<int,int>>> graph;

int n,m;
int parent[100];
int dist[100];

int find(int v){
  if(parent[v]==v){
    return v;
  }
  return find(parent[v]);
}

void combine(int v,int w){
  int v1 = find(v);
  int w1 = find(w);
  if(dist[v1]>dist[w1]){
    parent[w1] = v1;
  }else{
    parent[v1] = w1;
    dist[w1] = max(dist[w1],dist[v1]+1);
  }
}

int main() {
  for(int i=0;i<100;i++){
    parent[i]=i;
    dist[i]=0;
  }
  cin>>n>>m;
  for(int i=0;i<m;i++){
    int x,y,d;
    cin>>x>>y>>d;
    graph.push_back({d,{x,y}});
  }

  int c,i,tot = 0;
  while(i<graph.size()&&c<n-1){
    pair<int,pair<int,int>> curredge = graph[i];
    int d = curredge.first;
    int x = curredge.second.first;
    int y = curredge.second.second;

    if(find(x)!=find(y)){
      c++;
      tot+=d;
      combine(x,y);
    }
    i++;
  }
  cout<<tot;
} 