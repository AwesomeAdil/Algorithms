#include <iostream>
#include <vector>

using namespace std;

vector<int> adjlist[1005];
bool visited[1005];
//traversing through the adjlist

void dfs(int x, int loc){
if(visited[x]){
  return;
}
visited[x] = true;

for(int u : adjlist[x]){
  if(visited[u]) continue;
  if(u==loc){
    return;
  }
  dfs(u,loc);
}
return;
}

int main() {
  //NODES AND EDGES
  int n,m;

  cin>>n>>m;
  for(int i=0;i<m;i++){
    int a,b;
    cin>>a>>b;
    //ADD EDGE
    adjlist[a].push_back(b);
    //BIDIRECTIONAL
    adjlist[b].push_back(a);
  }

  dfs(0,10);

} 