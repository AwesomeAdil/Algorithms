#include <iostream>
#include <queue>
#include <utility>
using namespace std;
int n,m;
vector< pair<int,int> > adjlist[1005];
priority_queue<pair<int,int>, vector<pair<int,int>>, greater<pair<int,int>>> pq;
int dist[1005];
int main() {
cin>>n>>m;

for(int i=0;i<m;i++){
  int x,y,d;
  cin>>x>>y>>d;
  adjlist[x].push_back({d,y});
  adjlist[y].push_back({d,x});
}

for(int i=0;i<n;i++){
  dist[i] = -1;
}

pq.push({0,0});

while(!pq.empty()){
  pair<int,int> dv;
  dv = pq.top();
  pq.pop();
  if(dist[dv.second]!=-1){
    continue;
  }
  dist[dv.second]=dv.first;

  for(pair<int,int> j : adjlist[dv.second]){
    if(dist[j.second]==-1){
      pq.push({j.first+dv.first,j.second});
    }
  }
}

for(int i=0;i<n;i++){
  cout<<dist[i];
  cout<<" ";
}

} 


/*

UNDERSTANDING DIJKSTRAS

0) We make an adjlist with edges correctly and initialize number of nodes and edges

1) first we make a priority queue which puts the smallest edge on the top
2) We also make an array of distances to both show if we found a smallest distance and what that smallest distance is
3) We go from our point and look at all the neighbors. 
4) If the neighbor has been seen already that means we already came to it
5) If not we add to priority queue and check 



*/